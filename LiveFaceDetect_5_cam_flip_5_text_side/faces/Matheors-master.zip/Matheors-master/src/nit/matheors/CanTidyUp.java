package nit.matheors;

public interface CanTidyUp {

	void tidyUp();

}
