package nit.matheors;

import processing.core.PApplet;

public abstract class Bootstrap {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PApplet.main(new String[] { "--present", "nit.matheors.Matheors" });
	}

}
