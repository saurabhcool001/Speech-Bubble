package nit.matheors.model.objects;

public enum MatheorSize {
	SMALL, BIG
}
