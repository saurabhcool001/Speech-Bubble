package nit.matheors.model.objects;

public enum ShotType {

	ADDITION, SUBTRACTION
	
}
