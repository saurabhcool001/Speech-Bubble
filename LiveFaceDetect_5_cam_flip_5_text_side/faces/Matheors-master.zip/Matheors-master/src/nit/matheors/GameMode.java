package nit.matheors;

public enum GameMode {
	MAIN_MENU, GAME, ENDING
}
