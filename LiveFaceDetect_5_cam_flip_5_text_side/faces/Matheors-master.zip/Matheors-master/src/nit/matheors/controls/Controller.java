package nit.matheors.controls;

public interface Controller {

	void control(Controllable controllable, Object... params);
	
}
