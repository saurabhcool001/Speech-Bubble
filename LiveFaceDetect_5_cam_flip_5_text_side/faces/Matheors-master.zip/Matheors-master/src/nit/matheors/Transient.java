package nit.matheors;

public interface Transient {

}
